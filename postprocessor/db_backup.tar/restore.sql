--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.songs DROP CONSTRAINT songs_album_id_fkey;
ALTER TABLE ONLY public.similar_artists DROP CONSTRAINT similar_artists_artist2_id_fkey;
ALTER TABLE ONLY public.similar_artists DROP CONSTRAINT similar_artists_artist1_id_fkey;
ALTER TABLE ONLY public.playlists_metadata DROP CONSTRAINT playlists_metadata_playlist_id_fkey;
ALTER TABLE ONLY public.artist_genres DROP CONSTRAINT artist_genres_genre_id_fkey;
ALTER TABLE ONLY public.artist_genres DROP CONSTRAINT artist_genres_artist_id_fkey;
ALTER TABLE ONLY public.albums DROP CONSTRAINT albums_artist_id_fkey;
ALTER TABLE ONLY public.album_genres DROP CONSTRAINT album_genres_genre_id_fkey;
ALTER TABLE ONLY public.album_genres DROP CONSTRAINT album_genres_album_id_fkey;
DROP INDEX public.song_ix;
DROP INDEX public.artist_ix;
DROP INDEX public.artist_idx;
DROP INDEX public.album_ix;
DROP INDEX public.album_idx;
ALTER TABLE ONLY public.songs DROP CONSTRAINT songs_pkey;
ALTER TABLE ONLY public.playlists DROP CONSTRAINT playlists_pkey;
ALTER TABLE ONLY public.playlists_metadata DROP CONSTRAINT playlist_pkey;
ALTER TABLE ONLY public.liners DROP CONSTRAINT liners_pkey;
ALTER TABLE ONLY public.genres DROP CONSTRAINT genres_pkey;
ALTER TABLE ONLY public.genres DROP CONSTRAINT genres_genre_key;
ALTER TABLE ONLY public.genres_blacklist DROP CONSTRAINT genres_blacklist_pkey;
ALTER TABLE ONLY public.genres_blacklist DROP CONSTRAINT genres_blacklist_genre_key;
ALTER TABLE ONLY public.artists DROP CONSTRAINT artists_pkey;
ALTER TABLE ONLY public.artists DROP CONSTRAINT artists_artist_key;
ALTER TABLE ONLY public.artist_genres DROP CONSTRAINT artist_genre_pkey;
ALTER TABLE ONLY public.similar_artists DROP CONSTRAINT artist_artist_pkey;
ALTER TABLE ONLY public.albums DROP CONSTRAINT albums_pkey;
ALTER TABLE ONLY public.album_genres DROP CONSTRAINT album_genre_pkey;
ALTER TABLE public.songs ALTER COLUMN song_id DROP DEFAULT;
ALTER TABLE public.playlists_metadata ALTER COLUMN playlist_id DROP DEFAULT;
ALTER TABLE public.playlists ALTER COLUMN playlist_id DROP DEFAULT;
ALTER TABLE public.liners ALTER COLUMN liner_id DROP DEFAULT;
ALTER TABLE public.genres_blacklist ALTER COLUMN genre_id DROP DEFAULT;
ALTER TABLE public.genres ALTER COLUMN genre_id DROP DEFAULT;
ALTER TABLE public.artists ALTER COLUMN artist_id DROP DEFAULT;
ALTER TABLE public.albums ALTER COLUMN album_id DROP DEFAULT;
DROP SEQUENCE public.songs_song_id_seq;
DROP TABLE public.songs;
DROP TABLE public.similar_artists;
DROP SEQUENCE public.playlists_playlist_id_seq;
DROP SEQUENCE public.playlists_metadata_playlist_id_seq;
DROP TABLE public.playlists_metadata;
DROP TABLE public.playlists;
DROP SEQUENCE public.liners_liner_id_seq;
DROP TABLE public.liners;
DROP SEQUENCE public.genres_genre_id_seq;
DROP SEQUENCE public.genres_blacklist_genre_id_seq;
DROP TABLE public.genres_blacklist;
DROP TABLE public.genres;
DROP SEQUENCE public.artists_artist_id_seq;
DROP TABLE public.artists;
DROP TABLE public.artist_genres;
DROP SEQUENCE public.albums_album_id_seq;
DROP TABLE public.albums;
DROP TABLE public.album_genres;
DROP TYPE public.liner_category;
DROP TYPE public.genre_category;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: jon
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO jon;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: jon
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: genre_category; Type: TYPE; Schema: public; Owner: jon
--

CREATE TYPE genre_category AS ENUM (
    'specialty',
    'rock',
    'hip-hop',
    'electronic',
    'alternative'
);


ALTER TYPE genre_category OWNER TO jon;

--
-- Name: liner_category; Type: TYPE; Schema: public; Owner: jon
--

CREATE TYPE liner_category AS ENUM (
    'liner',
    'legal_id',
    'underwriter',
    'PSA'
);


ALTER TYPE liner_category OWNER TO jon;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: album_genres; Type: TABLE; Schema: public; Owner: jon; Tablespace: 
--

CREATE TABLE album_genres (
    album_id integer NOT NULL,
    genre_id smallint NOT NULL,
    similarity double precision DEFAULT 0.0 NOT NULL
);


ALTER TABLE album_genres OWNER TO jon;

--
-- Name: albums; Type: TABLE; Schema: public; Owner: jon; Tablespace: 
--

CREATE TABLE albums (
    album_id integer NOT NULL,
    album text NOT NULL,
    folder_path text DEFAULT ''::text NOT NULL,
    spotify_popularity integer DEFAULT 0 NOT NULL,
    lastfm_listeners integer DEFAULT 0 NOT NULL,
    lastfm_playcount integer DEFAULT 0 NOT NULL,
    whatcd_seeders integer DEFAULT 0 NOT NULL,
    whatcd_snatches integer DEFAULT 0 NOT NULL,
    artist_id integer NOT NULL,
    downloadability double precision DEFAULT 0 NOT NULL
);


ALTER TABLE albums OWNER TO jon;

--
-- Name: albums_album_id_seq; Type: SEQUENCE; Schema: public; Owner: jon
--

CREATE SEQUENCE albums_album_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE albums_album_id_seq OWNER TO jon;

--
-- Name: albums_album_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jon
--

ALTER SEQUENCE albums_album_id_seq OWNED BY albums.album_id;


--
-- Name: artist_genres; Type: TABLE; Schema: public; Owner: jon; Tablespace: 
--

CREATE TABLE artist_genres (
    artist_id smallint NOT NULL,
    genre_id integer NOT NULL,
    similarity double precision DEFAULT 0.0 NOT NULL
);


ALTER TABLE artist_genres OWNER TO jon;

--
-- Name: artists; Type: TABLE; Schema: public; Owner: jon; Tablespace: 
--

CREATE TABLE artists (
    artist_id integer NOT NULL,
    artist text NOT NULL,
    spotify_popularity integer DEFAULT 0 NOT NULL,
    lastfm_listeners integer DEFAULT 0 NOT NULL,
    lastfm_playcount integer DEFAULT 0 NOT NULL,
    whatcd_seeders integer DEFAULT 0 NOT NULL,
    whatcd_snatches integer DEFAULT 0 NOT NULL
);


ALTER TABLE artists OWNER TO jon;

--
-- Name: artists_artist_id_seq; Type: SEQUENCE; Schema: public; Owner: jon
--

CREATE SEQUENCE artists_artist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE artists_artist_id_seq OWNER TO jon;

--
-- Name: artists_artist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jon
--

ALTER SEQUENCE artists_artist_id_seq OWNED BY artists.artist_id;


--
-- Name: genres; Type: TABLE; Schema: public; Owner: jon; Tablespace: 
--

CREATE TABLE genres (
    genre_id smallint NOT NULL,
    genre text NOT NULL,
    supergenre genre_category NOT NULL,
    popularity double precision DEFAULT 0 NOT NULL,
    CONSTRAINT genres_genre_check CHECK ((genre !~ '^\d*.$'::text))
);


ALTER TABLE genres OWNER TO jon;

--
-- Name: genres_blacklist; Type: TABLE; Schema: public; Owner: jon; Tablespace: 
--

CREATE TABLE genres_blacklist (
    genre_id smallint NOT NULL,
    genre text NOT NULL,
    permanent boolean DEFAULT false NOT NULL
);


ALTER TABLE genres_blacklist OWNER TO jon;

--
-- Name: genres_blacklist_genre_id_seq; Type: SEQUENCE; Schema: public; Owner: jon
--

CREATE SEQUENCE genres_blacklist_genre_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE genres_blacklist_genre_id_seq OWNER TO jon;

--
-- Name: genres_blacklist_genre_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jon
--

ALTER SEQUENCE genres_blacklist_genre_id_seq OWNED BY genres_blacklist.genre_id;


--
-- Name: genres_genre_id_seq; Type: SEQUENCE; Schema: public; Owner: jon
--

CREATE SEQUENCE genres_genre_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE genres_genre_id_seq OWNER TO jon;

--
-- Name: genres_genre_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jon
--

ALTER SEQUENCE genres_genre_id_seq OWNED BY genres.genre_id;


--
-- Name: liners; Type: TABLE; Schema: public; Owner: jon; Tablespace: 
--

CREATE TABLE liners (
    liner_id integer NOT NULL,
    liner text NOT NULL,
    file_path text NOT NULL,
    length smallint NOT NULL,
    type liner_category NOT NULL
);


ALTER TABLE liners OWNER TO jon;

--
-- Name: liners_liner_id_seq; Type: SEQUENCE; Schema: public; Owner: jon
--

CREATE SEQUENCE liners_liner_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE liners_liner_id_seq OWNER TO jon;

--
-- Name: liners_liner_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jon
--

ALTER SEQUENCE liners_liner_id_seq OWNED BY liners.liner_id;


--
-- Name: playlists; Type: TABLE; Schema: public; Owner: jon; Tablespace: 
--

CREATE TABLE playlists (
    playlist_id integer NOT NULL,
    genre genre_category NOT NULL,
    subgenre text NOT NULL,
    transition_to genre_category,
    transition_from genre_category,
    plays integer DEFAULT 0 NOT NULL,
    last_played date DEFAULT '1969-04-17'::date NOT NULL
);


ALTER TABLE playlists OWNER TO jon;

--
-- Name: playlists_metadata; Type: TABLE; Schema: public; Owner: jon; Tablespace: 
--

CREATE TABLE playlists_metadata (
    playlist_id integer NOT NULL,
    file_path text NOT NULL,
    "interval" smallint NOT NULL
);


ALTER TABLE playlists_metadata OWNER TO jon;

--
-- Name: playlists_metadata_playlist_id_seq; Type: SEQUENCE; Schema: public; Owner: jon
--

CREATE SEQUENCE playlists_metadata_playlist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE playlists_metadata_playlist_id_seq OWNER TO jon;

--
-- Name: playlists_metadata_playlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jon
--

ALTER SEQUENCE playlists_metadata_playlist_id_seq OWNED BY playlists_metadata.playlist_id;


--
-- Name: playlists_playlist_id_seq; Type: SEQUENCE; Schema: public; Owner: jon
--

CREATE SEQUENCE playlists_playlist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE playlists_playlist_id_seq OWNER TO jon;

--
-- Name: playlists_playlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jon
--

ALTER SEQUENCE playlists_playlist_id_seq OWNED BY playlists.playlist_id;


--
-- Name: similar_artists; Type: TABLE; Schema: public; Owner: jon; Tablespace: 
--

CREATE TABLE similar_artists (
    artist1_id integer NOT NULL,
    artist2_id integer NOT NULL,
    similarity double precision DEFAULT 0 NOT NULL,
    CONSTRAINT artist_order CHECK ((artist1_id > artist2_id))
);


ALTER TABLE similar_artists OWNER TO jon;

--
-- Name: songs; Type: TABLE; Schema: public; Owner: jon; Tablespace: 
--

CREATE TABLE songs (
    song_id integer NOT NULL,
    song text NOT NULL,
    filename text NOT NULL,
    album_id integer NOT NULL,
    length smallint NOT NULL,
    explicit boolean NOT NULL,
    spotify_popularity integer DEFAULT 0 NOT NULL,
    lastfm_listeners integer DEFAULT 0 NOT NULL,
    lastfm_playcount integer DEFAULT 0 NOT NULL,
    popularity double precision DEFAULT 0 NOT NULL,
    playcount integer DEFAULT 0 NOT NULL,
    playlists integer DEFAULT 0 NOT NULL
);


ALTER TABLE songs OWNER TO jon;

--
-- Name: songs_song_id_seq; Type: SEQUENCE; Schema: public; Owner: jon
--

CREATE SEQUENCE songs_song_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE songs_song_id_seq OWNER TO jon;

--
-- Name: songs_song_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jon
--

ALTER SEQUENCE songs_song_id_seq OWNED BY songs.song_id;


--
-- Name: album_id; Type: DEFAULT; Schema: public; Owner: jon
--

ALTER TABLE ONLY albums ALTER COLUMN album_id SET DEFAULT nextval('albums_album_id_seq'::regclass);


--
-- Name: artist_id; Type: DEFAULT; Schema: public; Owner: jon
--

ALTER TABLE ONLY artists ALTER COLUMN artist_id SET DEFAULT nextval('artists_artist_id_seq'::regclass);


--
-- Name: genre_id; Type: DEFAULT; Schema: public; Owner: jon
--

ALTER TABLE ONLY genres ALTER COLUMN genre_id SET DEFAULT nextval('genres_genre_id_seq'::regclass);


--
-- Name: genre_id; Type: DEFAULT; Schema: public; Owner: jon
--

ALTER TABLE ONLY genres_blacklist ALTER COLUMN genre_id SET DEFAULT nextval('genres_blacklist_genre_id_seq'::regclass);


--
-- Name: liner_id; Type: DEFAULT; Schema: public; Owner: jon
--

ALTER TABLE ONLY liners ALTER COLUMN liner_id SET DEFAULT nextval('liners_liner_id_seq'::regclass);


--
-- Name: playlist_id; Type: DEFAULT; Schema: public; Owner: jon
--

ALTER TABLE ONLY playlists ALTER COLUMN playlist_id SET DEFAULT nextval('playlists_playlist_id_seq'::regclass);


--
-- Name: playlist_id; Type: DEFAULT; Schema: public; Owner: jon
--

ALTER TABLE ONLY playlists_metadata ALTER COLUMN playlist_id SET DEFAULT nextval('playlists_metadata_playlist_id_seq'::regclass);


--
-- Name: song_id; Type: DEFAULT; Schema: public; Owner: jon
--

ALTER TABLE ONLY songs ALTER COLUMN song_id SET DEFAULT nextval('songs_song_id_seq'::regclass);


--
-- Data for Name: album_genres; Type: TABLE DATA; Schema: public; Owner: jon
--

COPY album_genres (album_id, genre_id, similarity) FROM stdin;
\.
COPY album_genres (album_id, genre_id, similarity) FROM '$$PATH$$/2409.dat';

--
-- Data for Name: albums; Type: TABLE DATA; Schema: public; Owner: jon
--

COPY albums (album_id, album, folder_path, spotify_popularity, lastfm_listeners, lastfm_playcount, whatcd_seeders, whatcd_snatches, artist_id, downloadability) FROM stdin;
\.
COPY albums (album_id, album, folder_path, spotify_popularity, lastfm_listeners, lastfm_playcount, whatcd_seeders, whatcd_snatches, artist_id, downloadability) FROM '$$PATH$$/2408.dat';

--
-- Name: albums_album_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jon
--

SELECT pg_catalog.setval('albums_album_id_seq', 1104, true);


--
-- Data for Name: artist_genres; Type: TABLE DATA; Schema: public; Owner: jon
--

COPY artist_genres (artist_id, genre_id, similarity) FROM stdin;
\.
COPY artist_genres (artist_id, genre_id, similarity) FROM '$$PATH$$/2406.dat';

--
-- Data for Name: artists; Type: TABLE DATA; Schema: public; Owner: jon
--

COPY artists (artist_id, artist, spotify_popularity, lastfm_listeners, lastfm_playcount, whatcd_seeders, whatcd_snatches) FROM stdin;
\.
COPY artists (artist_id, artist, spotify_popularity, lastfm_listeners, lastfm_playcount, whatcd_seeders, whatcd_snatches) FROM '$$PATH$$/2404.dat';

--
-- Name: artists_artist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jon
--

SELECT pg_catalog.setval('artists_artist_id_seq', 3840, true);


--
-- Data for Name: genres; Type: TABLE DATA; Schema: public; Owner: jon
--

COPY genres (genre_id, genre, supergenre, popularity) FROM stdin;
\.
COPY genres (genre_id, genre, supergenre, popularity) FROM '$$PATH$$/2402.dat';

--
-- Data for Name: genres_blacklist; Type: TABLE DATA; Schema: public; Owner: jon
--

COPY genres_blacklist (genre_id, genre, permanent) FROM stdin;
\.
COPY genres_blacklist (genre_id, genre, permanent) FROM '$$PATH$$/2419.dat';

--
-- Name: genres_blacklist_genre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jon
--

SELECT pg_catalog.setval('genres_blacklist_genre_id_seq', 4222, true);


--
-- Name: genres_genre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jon
--

SELECT pg_catalog.setval('genres_genre_id_seq', 860, true);


--
-- Data for Name: liners; Type: TABLE DATA; Schema: public; Owner: jon
--

COPY liners (liner_id, liner, file_path, length, type) FROM stdin;
\.
COPY liners (liner_id, liner, file_path, length, type) FROM '$$PATH$$/2413.dat';

--
-- Name: liners_liner_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jon
--

SELECT pg_catalog.setval('liners_liner_id_seq', 1, false);


--
-- Data for Name: playlists; Type: TABLE DATA; Schema: public; Owner: jon
--

COPY playlists (playlist_id, genre, subgenre, transition_to, transition_from, plays, last_played) FROM stdin;
\.
COPY playlists (playlist_id, genre, subgenre, transition_to, transition_from, plays, last_played) FROM '$$PATH$$/2415.dat';

--
-- Data for Name: playlists_metadata; Type: TABLE DATA; Schema: public; Owner: jon
--

COPY playlists_metadata (playlist_id, file_path, "interval") FROM stdin;
\.
COPY playlists_metadata (playlist_id, file_path, "interval") FROM '$$PATH$$/2417.dat';

--
-- Name: playlists_metadata_playlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jon
--

SELECT pg_catalog.setval('playlists_metadata_playlist_id_seq', 1, false);


--
-- Name: playlists_playlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jon
--

SELECT pg_catalog.setval('playlists_playlist_id_seq', 1, false);


--
-- Data for Name: similar_artists; Type: TABLE DATA; Schema: public; Owner: jon
--

COPY similar_artists (artist1_id, artist2_id, similarity) FROM stdin;
\.
COPY similar_artists (artist1_id, artist2_id, similarity) FROM '$$PATH$$/2405.dat';

--
-- Data for Name: songs; Type: TABLE DATA; Schema: public; Owner: jon
--

COPY songs (song_id, song, filename, album_id, length, explicit, spotify_popularity, lastfm_listeners, lastfm_playcount, popularity, playcount, playlists) FROM stdin;
\.
COPY songs (song_id, song, filename, album_id, length, explicit, spotify_popularity, lastfm_listeners, lastfm_playcount, popularity, playcount, playlists) FROM '$$PATH$$/2411.dat';

--
-- Name: songs_song_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jon
--

SELECT pg_catalog.setval('songs_song_id_seq', 17, true);


--
-- Name: album_genre_pkey; Type: CONSTRAINT; Schema: public; Owner: jon; Tablespace: 
--

ALTER TABLE ONLY album_genres
    ADD CONSTRAINT album_genre_pkey PRIMARY KEY (album_id, genre_id);


--
-- Name: albums_pkey; Type: CONSTRAINT; Schema: public; Owner: jon; Tablespace: 
--

ALTER TABLE ONLY albums
    ADD CONSTRAINT albums_pkey PRIMARY KEY (album_id);


--
-- Name: artist_artist_pkey; Type: CONSTRAINT; Schema: public; Owner: jon; Tablespace: 
--

ALTER TABLE ONLY similar_artists
    ADD CONSTRAINT artist_artist_pkey PRIMARY KEY (artist1_id, artist2_id);


--
-- Name: artist_genre_pkey; Type: CONSTRAINT; Schema: public; Owner: jon; Tablespace: 
--

ALTER TABLE ONLY artist_genres
    ADD CONSTRAINT artist_genre_pkey PRIMARY KEY (artist_id, genre_id);


--
-- Name: artists_artist_key; Type: CONSTRAINT; Schema: public; Owner: jon; Tablespace: 
--

ALTER TABLE ONLY artists
    ADD CONSTRAINT artists_artist_key UNIQUE (artist);


--
-- Name: artists_pkey; Type: CONSTRAINT; Schema: public; Owner: jon; Tablespace: 
--

ALTER TABLE ONLY artists
    ADD CONSTRAINT artists_pkey PRIMARY KEY (artist_id);


--
-- Name: genres_blacklist_genre_key; Type: CONSTRAINT; Schema: public; Owner: jon; Tablespace: 
--

ALTER TABLE ONLY genres_blacklist
    ADD CONSTRAINT genres_blacklist_genre_key UNIQUE (genre);


--
-- Name: genres_blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: jon; Tablespace: 
--

ALTER TABLE ONLY genres_blacklist
    ADD CONSTRAINT genres_blacklist_pkey PRIMARY KEY (genre_id);


--
-- Name: genres_genre_key; Type: CONSTRAINT; Schema: public; Owner: jon; Tablespace: 
--

ALTER TABLE ONLY genres
    ADD CONSTRAINT genres_genre_key UNIQUE (genre);


--
-- Name: genres_pkey; Type: CONSTRAINT; Schema: public; Owner: jon; Tablespace: 
--

ALTER TABLE ONLY genres
    ADD CONSTRAINT genres_pkey PRIMARY KEY (genre_id);


--
-- Name: liners_pkey; Type: CONSTRAINT; Schema: public; Owner: jon; Tablespace: 
--

ALTER TABLE ONLY liners
    ADD CONSTRAINT liners_pkey PRIMARY KEY (liner_id);


--
-- Name: playlist_pkey; Type: CONSTRAINT; Schema: public; Owner: jon; Tablespace: 
--

ALTER TABLE ONLY playlists_metadata
    ADD CONSTRAINT playlist_pkey PRIMARY KEY (playlist_id);


--
-- Name: playlists_pkey; Type: CONSTRAINT; Schema: public; Owner: jon; Tablespace: 
--

ALTER TABLE ONLY playlists
    ADD CONSTRAINT playlists_pkey PRIMARY KEY (playlist_id);


--
-- Name: songs_pkey; Type: CONSTRAINT; Schema: public; Owner: jon; Tablespace: 
--

ALTER TABLE ONLY songs
    ADD CONSTRAINT songs_pkey PRIMARY KEY (song_id);


--
-- Name: album_idx; Type: INDEX; Schema: public; Owner: jon; Tablespace: 
--

CREATE INDEX album_idx ON songs USING hash (album_id);


--
-- Name: album_ix; Type: INDEX; Schema: public; Owner: jon; Tablespace: 
--

CREATE INDEX album_ix ON albums USING hash (album);


--
-- Name: artist_idx; Type: INDEX; Schema: public; Owner: jon; Tablespace: 
--

CREATE INDEX artist_idx ON albums USING hash (artist_id);


--
-- Name: artist_ix; Type: INDEX; Schema: public; Owner: jon; Tablespace: 
--

CREATE INDEX artist_ix ON artists USING hash (artist);


--
-- Name: song_ix; Type: INDEX; Schema: public; Owner: jon; Tablespace: 
--

CREATE INDEX song_ix ON songs USING hash (song);


--
-- Name: album_genres_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jon
--

ALTER TABLE ONLY album_genres
    ADD CONSTRAINT album_genres_album_id_fkey FOREIGN KEY (album_id) REFERENCES albums(album_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: album_genres_genre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jon
--

ALTER TABLE ONLY album_genres
    ADD CONSTRAINT album_genres_genre_id_fkey FOREIGN KEY (genre_id) REFERENCES genres(genre_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: albums_artist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jon
--

ALTER TABLE ONLY albums
    ADD CONSTRAINT albums_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES artists(artist_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: artist_genres_artist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jon
--

ALTER TABLE ONLY artist_genres
    ADD CONSTRAINT artist_genres_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES artists(artist_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: artist_genres_genre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jon
--

ALTER TABLE ONLY artist_genres
    ADD CONSTRAINT artist_genres_genre_id_fkey FOREIGN KEY (genre_id) REFERENCES genres(genre_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: playlists_metadata_playlist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jon
--

ALTER TABLE ONLY playlists_metadata
    ADD CONSTRAINT playlists_metadata_playlist_id_fkey FOREIGN KEY (playlist_id) REFERENCES playlists(playlist_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: similar_artists_artist1_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jon
--

ALTER TABLE ONLY similar_artists
    ADD CONSTRAINT similar_artists_artist1_id_fkey FOREIGN KEY (artist1_id) REFERENCES artists(artist_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: similar_artists_artist2_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jon
--

ALTER TABLE ONLY similar_artists
    ADD CONSTRAINT similar_artists_artist2_id_fkey FOREIGN KEY (artist2_id) REFERENCES artists(artist_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: songs_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jon
--

ALTER TABLE ONLY songs
    ADD CONSTRAINT songs_album_id_fkey FOREIGN KEY (album_id) REFERENCES albums(album_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: public; Type: ACL; Schema: -; Owner: jon
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM jon;
GRANT ALL ON SCHEMA public TO jon;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

